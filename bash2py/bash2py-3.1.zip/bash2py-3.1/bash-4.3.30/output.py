#! /usr/bin/env python
import subprocess
_rc0 = subprocess.call(["vi","junk.py"],shell=True)
_rc0 = subprocess.call(["./bash","junk"],shell=True)
_rc0 = subprocess.call(["vi","junk.py"],shell=True)
